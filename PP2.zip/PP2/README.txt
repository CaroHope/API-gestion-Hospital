---------------------------------------
Integrantes:
Marimel Nicole Suarez	20-0085
Nahomy Gomez			20-0079
Evelyn Carolina Jorge  	20-0084
---------------------------------------


Codigos del terminal en Visual Studio Code:
1- npm init -y
2- npm install express
3- node server.js //Para saber en que puerto corre el archivo y reiniciar el server
4- npm install nodemon --save-dev //Para automatizar el reiniciar el servidor \\
5- npm run start // Para correr el servidor automatico
6- npm i mysql express-myconnection //MySQL
---------------------------------------


Para crear la imagen de Docker:
docker build -t node-APIRest
