const express = require('express')
const routes = express.Router()

//Select o mostrar todo
routes.get('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)
       
       conn.query('SELECT * FROM sintomas', (err,rows)=>{
            if(err) return res.send(err)  
            
            res.json(rows) 
       })
    })
})


//Insertar los datos
routes.post('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('INSERT INTO sintomas set ?', [req.body] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('La consulta de síntomas ha sido creada!') 
        })

    })
})


//Eliminar un registro en especifico
routes.delete('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('DELETE FROM sintomas WHERE PAC_CODIGO = ?', [req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('La consulta de síntomas ha sido eliminada!') 
        })

    })
})


//Actualizar un registro en especifico
routes.put('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('UPDATE sintomas set ? WHERE PAC_CODIGO = ?', [req.body, req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('La consulta de síntomas ha sido actualizada!') 
        })

    })
})



module.exports = routes