const express = require('express')
const routes = express.Router()

//Select o mostrar todo
routes.get('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)
       
       conn.query('SELECT * FROM procedimiento_medico', (err,rows)=>{
            if(err) return res.send(err)  
            
            res.json(rows) 
       })
    })
})


//Insertar los datos
routes.post('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('INSERT INTO procedimiento_medico set ?', [req.body] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El procedimiento médico ha sido creado!') 
        })

    })
})


//Eliminar un registro en especifico
routes.delete('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('DELETE FROM procedimiento_medico WHERE PAC_CODIGO = ?', [req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El procedimiento médico ha sido eliminado!') 
        })

    })
})


//Actualizar un registro en especifico
routes.put('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('UPDATE procedimiento_medico set ? WHERE PAC_CODIGO = ?', [req.body, req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El procedimiento médico ha sido actualizado!') 
        })

    })
})



module.exports = routes