const express = require('express')
const routes = express.Router()

//Select o mostrar todo
routes.get('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)
       
       conn.query('SELECT * FROM doctores', (err,rows)=>{
            if(err) return res.send(err)  
            
            res.json(rows) 
       })
    })
})


//Insertar los datos
routes.post('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('INSERT INTO doctores set ?', [req.body] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El doctor ha sido insertado!') 
        })

    })
})


//Eliminar un registro en especifico
routes.delete('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('DELETE FROM doctores WHERE PAC_CODIGO = ?', [req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El doctor ha sido eliminado!') 
        })

    })
})


//Actualizar un registro en especifico
routes.put('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('UPDATE doctores set ? WHERE PAC_CODIGO = ?', [req.body, req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El doctor ha sido actualizado!') 
        })

    })
})



module.exports = routes