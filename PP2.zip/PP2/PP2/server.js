//Variables del servidor
const express = require ('express')
const mysql = require('mysql')
const myconn = require('express-myconnection')
const morgan = require('morgan')

const routesPacientes = require('./routesPacientes')
const routesDoctores = require('./routesDoctores')
const routesSintomas = require('./routesSintomas')
const routesProcedimientos = require('./routesProcedimientos')


//Puerto de la Api
const app = express()
app.set ('port', process.env.PORT || 9000) 


//BASE DE DATOS ----------------------------
const dboption ={
    host: 'localhost', 
    port: 3306, //puert0 mysql 
    user: 'root', //usuario bd
    password: 'root',
    database: 'hospital' //nombre de base de datos 
}

//middleware-------------------------------
app.use(myconn(mysql, dboption, 'single'))
app.use(express.json())
app.use(morgan('dev'))


//Rutas---------------------
app.get('/', (req, res) => {
    res.send ('Hola! Esta API es para gestion de un Hospital')
})

app.use('/pacientes', routesPacientes)
app.use('/doctores', routesDoctores)
app.use('/sintomas', routesSintomas)
app.use('/procedimientos', routesProcedimientos)
  


// SERVER RUN ---------------------------------------------- 
app.listen(app.get('port'), () =>{
    console.log('server running on port', app.get('port'))
} )
