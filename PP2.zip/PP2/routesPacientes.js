const express = require('express')
const routes = express.Router()

//Select o mostrar todo
routes.get('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)
       
       conn.query('SELECT * FROM pacientes', (err,rows)=>{
            if(err) return res.send(err)  
            
            res.json(rows) 
       })
    })
})


//Insertar los datos
routes.post('/', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('INSERT INTO pacientes set ?', [req.body] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El paciente ha sido insertado!') 
        })

    })
})


//Eliminar un registro en especifico
routes.delete('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('DELETE FROM pacientes WHERE PAC_CODIGO = ?', [req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El paciente ha sido eliminado!') 
        })

    })
})


//Actualizar un registro en especifico
routes.put('/:id', (req,res)=>{
    req.getConnection((err,conn)=>{
       if(err) return res.send(err)

              conn.query('UPDATE pacientes set ? WHERE PAC_CODIGO = ?', [req.body, req.params.id] , (err,rows)=>{
             if(err) return res.send(err)  
            
             res.send('El paciente ha sido actualizado!') 
        })

    })
})



module.exports = routes