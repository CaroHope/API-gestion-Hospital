## Tabla de contenido
* Integrantes
* Tecnologías
* Comandos


INTEGRANTES
-------------------------------
Integrantes:
Marimel Nicole Suarez	20-0085
Nahomy Gomez            20-0079
Evelyn Carolina Jorge  	20-0084
-------------------------------

TECNOLOGÍAS
-------------
1- NodeJS
2- Express
3- Postman
4- Morgan
5- Docker
6- MySQL
-------------

COMANDOS
--------------------------------------------------------------------------
Comandos utilizados en la terminal de Visual Studio Code:
1- npm init -y
2- npm install express
3- node server.js //Para saber en que puerto corre el archivo y reiniciar el server
4- npm install nodemon --save-dev //Para automatizar el reiniciar el servidor \\
5- npm run start // Para correr el servidor automatico
6- npm i mysql express-myconnection //MySQL
7- docker build -t node-apirest . //Crear imagen
8- docker images //Confirmar que la imagen se ha creado
9- docker run -it node-apirest //Ejecutar imagen
10- docker run -d -p 4000:9000 node-apirest //Ejecutar el contenedor como un proceso en el puerto 4000
11- docker ps //Para ver que procesos se están ejecutando
12- docker stop [ID del proceso] //Para detener el contenedor
--------------------------------------------------------------------------